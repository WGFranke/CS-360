package com.example.project2_frankeinventorymanagementapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    public interface OnItemActionListener {
        void onIncrement(InventoryItem item);
        void onDecrement(InventoryItem item);
        void onDelete(InventoryItem item);
    }

    private List<InventoryItem> items = new ArrayList<>();
    private final OnItemActionListener listener;

    public InventoryAdapter(OnItemActionListener listener) {
        this.listener = listener;
    }

    public void setItems(List<InventoryItem> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.tvItemName.setText(item.itemName);
        holder.tvCategory.setText(item.category);
        holder.tvQuantity.setText("Qty: " + item.quantity);

        holder.btnIncrement.setOnClickListener(v -> listener.onIncrement(item));
        holder.btnDecrement.setOnClickListener(v -> listener.onDecrement(item));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvItemName, tvCategory, tvQuantity;
        Button btnIncrement, btnDecrement;
        ImageButton btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            btnIncrement = itemView.findViewById(R.id.btnIncrease);
            btnDecrement = itemView.findViewById(R.id.btnDecrease);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
