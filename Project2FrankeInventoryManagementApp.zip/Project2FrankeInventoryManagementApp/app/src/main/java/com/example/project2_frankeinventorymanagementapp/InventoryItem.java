package com.example.project2_frankeinventorymanagementapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory")
public class InventoryItem {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String itemName;
    public int quantity;
    public String description;
    public String category;

    public InventoryItem(String itemName, int quantity, String description, String category) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.description = description;
        this.category = category;
    }
}