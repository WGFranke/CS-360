package com.example.project2_frankeinventorymanagementapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryFragment extends Fragment implements InventoryAdapter.OnItemActionListener {

    private AppDatabase db;
    private InventoryAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);

        db = AppDatabase.getInstance(requireContext());

        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        adapter = new InventoryAdapter(this);
        recyclerView.setAdapter(adapter);

        db.appDao().getAllItems().observe(getViewLifecycleOwner(), items -> adapter.setItems(items));

        FloatingActionButton fabAdd = view.findViewById(R.id.fabAdd);
        fabAdd.setOnClickListener(v -> ((MainActivity) requireActivity()).loadFragment(new AddEditItemFragment()));

        return view;
    }

    private void sendZeroStockNotification(String itemName) {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5555555555", null, "ALERT: Item " + itemName + " stock has reached ZERO!", null, null);
                Toast.makeText(getContext(), "Zero stock SMS alert sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(getContext(), "Failed to send SMS alert", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onIncrement(InventoryItem item) {
        item.quantity++;
        db.appDao().updateItem(item);
    }

    @Override
    public void onDecrement(InventoryItem item) {
        if (item.quantity > 0) {
            item.quantity--;
            db.appDao().updateItem(item);
            if (item.quantity == 0) {
                sendZeroStockNotification(item.itemName);
            }
        }
    }

    @Override
    public void onDelete(InventoryItem item) {
        db.appDao().deleteItem(item);
    }
}
